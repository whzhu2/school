<?php
    include './php/quit.php';
		session_start();
		$fullname = $username = $password = $email = "";
?>
<!DOCTYPE html>
<html>
<head>
<link href="./css/signup.css" type="text/css" rel="stylesheet" />
<link href="./css/style.css" type="text/css" rel="stylesheet" />
</head>
<body>


<div id="id01" class="modal">
<div class="tabs">
      <p>
      Site Map: <a href="./leaderboard.php">Leaderboard</a> |
      <a href="./game.php">Game Page</a>
      </p>
  </div>
  <form method="POST" class="modal-content" action="./game.php">
    <div class="container">
      <h1 align="center" >Login</h1>
      <p align="center">Please fill in this form to log into your account.</p>

	  <label for="username"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="username" required>

     <input align="center" type="submit" name="done" class="loginbtn" value="Login">

   <!--
	  <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw">


	 <?php
		if(isset($_POST['done'])){
			$myfile = fopen("users.html","r") or die("Unable to open file!");
			while(!feof($myfile)) {
			$values = explode(";",fgets($myfile));

			if(sizeof($values)==4 && strcmp( $values[1], $_POST['username'])==0 && strcmp($values[2], $_POST['psw'])==0 ){
				$username = $values[1];
				print("Login successfull");
				break;
			}

		}
		fclose($myfile);
		}

	 ?>
    -->
    </div>
  </form>
</div>

</body>
</html>
