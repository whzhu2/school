<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard</title>
    <link rel="stylesheet" href="./css/leader.css">
    <link href="./css/style.css" type="text/css" rel="stylesheet" />
</head>

<?php
    include './php/function.php';

    $input = file_get_contents("./res/save.txt");
    add_or_update($input);
    $sorted_scores;
    $count = 1;
    $scores = file("./res/scores.txt");
    foreach ($scores as $line){
        $person = explode(",",$line);
        $sorted_scores[$person[0]] = $person[1];
    }
    arsort($sorted_scores, SORT_NUMERIC);
   
?>

<body>
  <!-- SITE MAP -->
  <div class="tabs">
    <p>
    Site Map: <a href="./index.php">Login</a> | 
    <a href="./game.php">Game Page</a> |
    <a href="./php/key.php">Answer Key</a> |
    </p>
  </div>
  <!-- SITE MAP -->
    <div id="pic">
        <img src="./imgs/milpic2.png" alt="millionaire">
    </div>

    <div id="title">
        <h1>Leaderboard</h1>
    </div>

    <table id="board">
        <tr>
            <th>Position</th>
            <th>Name</th>
            <th>Score</th>
        </tr>

        <?php foreach($sorted_scores as $person => $score):?>
            <tr>
                <td><?=$count++?></td>
                <td><?=$person?></td>
                <td><?=$score?></td>
            </tr>
        <?php endforeach;?>

    </table>
</body>
</html>