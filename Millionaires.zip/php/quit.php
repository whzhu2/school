<html>
  <body>
    <?php
      
      function quit(){
        session_destroy();
      }

      function reload(){
        header("location:game.php");
      }

      function saveUser($user,$score){

        if($score < 0 || $score == ""){
          $score = 0;
        }
          $file = "./res/save.txt";
          $input = $user.",".$score;
          file_put_contents($file,$input, LOCK_EX);  
        header("location:leaderboard.php");
      }
      
    ?>
  </body>
</html>
