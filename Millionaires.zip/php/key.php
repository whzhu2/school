<html>
  <head>
  <title>Answer Key</title>
  </head>
  <body>
    <!-- SITE MAP -->
  <div>
    <p>
    Site Map: <a href="../index.php">Login</a> | 
    <a href="../game.php">Game Page</a> |
    <a href="../leaderboard.php">Leaderboard</a> |
    </p>
  </div>
  <!-- SITE MAP -->
    <?php
      $file = file_get_contents('../res/akey.txt');
      $file = explode("\n", $file);
      foreach($file as $value ){
        echo $value."</br>";
      }
    ?>
  </body>
</html>
