<?php
    function add_or_update($user_info){
        $scores = file_get_contents("./res/scores.txt");
        $user_info_arr = explode(",",$user_info);
        $is_there = find_user($user_info_arr[0]);
        if( find_user($is_there) !== false) {
            $scores = str_replace($is_there,$user_info, $scores);
            file_put_contents("./res/scores.txt", $scores);
        }else{
            file_put_contents("./res/scores.txt","\n".$user_info, FILE_APPEND);
        }
        
    }

    function find_user($name){
        $the_file = file("./res/scores.txt",FILE_SKIP_EMPTY_LINES);
        foreach($the_file as $persons){
            $line = strstr($persons, $name);
            if($line !== false){
                return $line;
            }
        }

        return false;
    }
?>