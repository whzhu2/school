<?php
  include './php/quit.php';
  session_start();

  if(isset($_POST['username'])){
    $_SESSION['username'] = $_POST['username'];
  }
  $currQuestion = $_SESSION['currQuestion'];
  $username = $_SESSION['username'];
  $score = $_SESSION['score'];
?>
<!DOCTYPE html>
<html lang="en">
<html>
  <head>
    <title>Millionaries</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>
    <div class="tabs">
      <p>
      Site Map: <a href="./index.php">Login</a> |
      <a href="./leaderboard.php">Leaderboard</a> |
      <a href="./php/key.php">Answer Key</a> |

      </p>
    </div>


  <div class = "container">

    <!--FORM SUBMISSION CODE-->
    <?php
        //Get Q&A Files
        $fileQ = file("./res/questions.txt");
        $fileA = file("./res/answers.txt");

        //Answer Key
        $ansKey = array("c","a","a","d");

        //Clear Session
        if(isset($_POST['quit']) || $currQuestion >= count($fileQ)){
          saveUser($username,$score);
          quit();
        }

        //Update Current Page
        if(isset($_POST['choice'])){
          reload();
        }

        //Set session variable
        $currQuestion = $_SESSION["currQuestion"];
        if($currQuestion == ""){
          $currQuestion = 0;
        }



        //Check if user response is correct
        if(isset($_POST['choice'])){
          if($_POST['choice'] == $ansKey[$currQuestion]){
            $_SESSION['currQuestion'] += 1;
            $_SESSION['score'] += 1;
          }else{
            $_SESSION['currQuestion'] += 1;
          }
        }

        //Load current Q&A
        $question = $fileQ[$currQuestion];
        $arrAnswers = explode(",",$fileA[$currQuestion]);

    ?>
    <!--FORM SUBMISSION CODE-->



    <div class = "pic">
      <img src="./imgs/milpic2.png" alt="image"></img>
    </div>
    <div class = "questions">
      <p><?php echo $question; ?></p>
    </div>

    <form  method="post" action="./game.php">
      <div class="midbox">
        <div class="midbox-btn">


          <div class="row1">
            <div class="cell">
              <input type="radio" id="a" name="choice" value="a" required>
              <label for="a" class="btn btn3">A)<?php echo $arrAnswers[0]; ?></label >
            </div>
            <div class="cell">
              <input type="radio" id="b" name="choice" value="b">
              <label for="b" class="btn btn3">B)<?php echo $arrAnswers[1]; ?></label>
            </div>
          </div>

          <div class="row2">
            <div class="cell">
              <input type="radio" id="c" name="choice" value="c">
              <label for="c" class="btn btn3">C)<?php echo $arrAnswers[2]; ?></label>
            </div>
            <div class="cell">
              <input type="radio" id="d" name="choice" value="d">
              <label for="d" class="btn btn3">D)<?php echo $arrAnswers[3];?></label>
            </div>
          </div>

        </div>

        <div class="row4">
          <div class="cell-btn">
          <input type="submit" value="Final Answer" id="sub" name="sub">
          <label for="sub" class="btn btn2" >Final Answer</label>

          </div>
    </form>
          <div class="cell-btn">
    <form  method="post" action="./game.php">
          <input type="submit" name="quit" value="Quit" id="q">
          <label for = "q" class="btn btnq">Quit</label>
    </form>
          </div>
        </div>
    </div>

  </div>
<!-- Cut Content
    <div class ="money">
      <ul>
        <li><a href="">$1,000,000</a></li>
        <li><a href="">$500,000</a></li>
        <li><a href="">$250,000</a></li>
        <li><a href="">$125,000</a></li>
        <li><a href="">$64,000</a></li>
        <li><a href="">$32,000</a></li>
        <li><a href="">$16,000</a></li>
        <li><a href="">$8,000</a></li>
        <li><a href="">$4,000</a></li>
        <li><a href="">$2,000</a></li>
        <li><a href="">$1,000</a></li>
        <li><a href="">$500</a></li>
        <li><a href="">$300</a></li>
        <li><a href="">$200</a></li>
        <li><a href="">$100</a></li>
      </ul>
    </div>
-->



  </body>
</html>
