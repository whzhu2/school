<?php include("head.html");?>
   
    <form action="matches-submit.php" method="get">
        <fieldset>
            <legend>Returning User:</legend>
            <ul>
                <li>
                   <input type="text" name="name" size="16" id="name">
                    <strong><label for="name" class="left">Name:</label></strong>
                </li>
            </ul>
            <input type="submit" value="View My Matches">
        </fieldset>              
    </form>
        
<?php include("tail.html");?>