<?php include("head.html");?>
<?php
    $user = array( //array to contain user info
        "name" => "",
        "gender" => "",
        "age" => "",
        "personality" => "",
        "os" => "",
        "min-age" => "",
        "max-age" => "",
        "seek-gender" => ""
    );
    //checking if all the post exists and adding to file
    if(isset($_POST["name"])){
        $user["name"] = $_POST["name"];
    }

    if(isset($_POST["gender"])){
        $user["gender"] = $_POST["gender"];
    }

    if(isset($_POST["age"])){
        $user["age"] = $_POST["age"];
    }   

    if(isset($_POST["personality"])){
        $user["personality"] = $_POST["personality"];
    }   

    if(isset($_POST["os"])){
        $user["os"] = $_POST["os"];
    }

    if(isset($_POST["min-age"])){
        $user["min-age"] = $_POST["min-age"];
    }

    if(isset($_POST["max-age"])){
        $user["max-age"] = $_POST["max-age"];
    }

    if(isset($_POST["seek-M"]) && isset($_POST["seek-F"])){
        $user["seek-gender"] = $_POST["seek-M"].$_POST["seek-F"];
    }
    
    $user_info = implode(",", $user); //making the array into a single string to be added to file
    
    file_put_contents("singles2.txt", "\n" .$user_info, FILE_APPEND);
?>


    <pre>
        <strong>Thank you!</strong> 

        Welcome to NerdLuv, <?= $user["name"] ?>!

        Now <a href="matches.php">Login to see your matches!</a>
    </pre>


<?php include("tail.html");?>