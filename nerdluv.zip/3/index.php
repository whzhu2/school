<?php include("head.html");?> <!--contains common banner and header for all pages -->
    <div>
        <h1>Welcome!</h1>
        <ul>
            <li>
                <img src="pics/sign.png" alt="sign">
                <a href="signup.php">Sign up for a new account</a>
            </li>
            <li>
                <img src="pics/heart.png" alt="">
                <a href="matches.php">Check your matches</a>
            </li>
        </ul>
    </div>
    
<?php include("tail.html");?> <!--contains common footer for all pages -->