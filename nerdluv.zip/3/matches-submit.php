<?php include("head.html");?>

<div>
    <strong>Matches for <?=$_GET["name"] ?></strong> <br>
</div>

<?php
    include("common.php");
    $hot_singles = file("singles2.txt", FILE_SKIP_EMPTY_LINES);

    foreach($hot_singles as $singles){
        $user_line = strstr($singles, $_GET["name"]); //find user line
        if ($user_line !== FALSE){
            break;
        }
    }
?>

<!--looping though all singles and then checking matches using a function-->

<?php foreach ($hot_singles as $singles): ?>
    <?php $single_arr = explode(",", $singles) ?>
    <?php if(match_singles($user_line, $singles)): ?>

        <div class="match">
            <p><img src="pics/user.png" alt=""></p>
            <div>
                <ul>
                    <li>
                        <p> <?= $single_arr[0]?> </p>
                    </li>

                    <li>
                        <strong>gender:</strong>
                        <?= $single_arr[1]?>
                    </li>

                    <li>
                        <strong>age:</strong>
                        <?= $single_arr[2]?>
                    </li>

                    <li>
                        <strong>type:</strong>
                        <?= $single_arr[3]?>
                    </li>

                    <li>
                        <strong>OS:</strong>
                        <?= $single_arr[4]?>
                    </li>

                    
                </ul>
            </div>
        </div>
    <?php endif; ?>
<?php endforeach;?>




<?php include("tail.html");?>