<?php

    //gets strings with users info, returns true if they are matches
    function match_singles($user, $other_single){

        //getting info from user
        $user_arr = explode(",", $user);
        $user_gender = $user_arr[1];
        $user_age = (int) $user_arr[2];
        $user_personality = $user_arr[3];
        $user_os = $user_arr[4];
        $user_min = (int) $user_arr[5];
        $user_max = (int) $user_arr[6];
        $user_seek_gender = $user_arr[7];

        //gettting info from potential match
        $other_arr = explode(",", $other_single);
        $other_gender = $other_arr[1];
        $other_age = (int) $other_arr[2];
        $other_personality = $other_arr[3];
        $other_os = $other_arr[4];
        $other_min = (int) $other_arr[5];
        $other_max = (int) $other_arr[6];
        $other_seek_gender = $other_arr[7];

        if( $user_arr[0] !== $other_arr[0]){ //check if same person
            if($user_min <= $other_age && $other_age <= $user_max){ //check if within age range
                if($other_min <= $user_age && $user_age <= $other_max){
                    if ($user_os === $other_os){ //check os
                        $pattern = "/[".$user_personality."]/"; //using regex to match letters
                        if(preg_match($pattern, $other_personality) === 1){
                            $pattern2 = "/[".$user_seek_gender."]/";
                            if(preg_match($pattern2, $other_gender) === 1){ //checks by seeing if user gender is in
                                $pattern3 = "/[".$other_seek_gender."]/"; //other users seek_gender nad vice versa
                                if(preg_match($pattern3, $user_gender) === 1){
                                    return TRUE;
                                }
                            }
                        }
                }   }
            }
        }

       return FALSE;
       
    }
?>