<?php include("head.html");?>

    <div>
        <form action="signup-submit.php" method="post">
            <fieldset>
                <legend>New User Signup:</legend>
                <ul>
                    <li>
                        <strong><label for="name" class="left">Name:</label></strong>
                        <input type="text" name="name" size="16" id ="name">
                    </li>
                   
                    <li>
                        <strong><label for="genderM" class="left">Gender:</label></strong>
                        <input type="radio" name="gender" value="M" id ="genderM">Male
                        <input type="radio" name="gender" value="F" id="genderF" checked>Female
                    </li> 
                    
                    <li> 
                        <strong><label for="age" class="left">Age:</label></strong>
                        <input type="text" name="age" size="6" maxlength="2" id="age">
                    </li> 
                   
                    <li>
                        <strong><label for="personality" class="left">Personality type:</label></strong>
                        <input type="text" name="personality" size="6" maxlength="4" id = "personality">
                        (<a href="http://www.humanmetrics.com/cgi-win/jtypes2.asp">Don't know your type?</a>)
                    </li> 

                    <li>
                        <strong><label for="os" class="left">Favorite OS:</label></strong>
                        <select name="os" id = "os"> 
                            <option value="Linux">Linux</option>
                            <option value="Mac OS X">Mac OS X</option>
                            <option value="Windows" selected>Windows</option>
                            
                        </select>
                    </li> 

                    <li>
                        <strong><label for="min-age" class="left">Seeking age:</label></strong>
                        <input type="text" name="min-age" size="6" maxlength="2" placeholder="min" id = "min-age">
                        to
                        <input type="text" name="max-age" size="6" maxlength="2" placeholder="max" id ="max-age">
                    </li> 

                    <li>
                        <strong><label for="seek-M" class="left">Seek Gender(s):</label></strong>
                        <input type="checkbox" name="seek-M" id="seek-M" value="M" checked>
                        <label for="seek-M">Male</label>
                        <input type="checkbox" name="seek-F" id="seek-F" value ="F">
                        <label for="seek-F">Female</label>
                    </li>
                </ul>
                <input type="submit" value="Sign up">
            </fieldset>
        </form>
    </div>

<?php include("tail.html");?>