
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Buy Your Way to a Better Education!</title>
		<link href="buyagrade.css" type="text/css" rel="stylesheet" />
	</head>

	<body>
		<?php
			$suckers = array();
			array_push($suckers, "Tiger Woods;MA;1234123412341234;visa");
			array_push($suckers, "Hulk Hogan;MF;5963109385987345;mastercard");
			array_push($suckers, "Matt Ryan;MC;7328904328904902;mastercard");
			array_push($suckers, "Louis Henry;MC;4444100020003000;visa");

			if( !isset($_POST['name']) || !isset($_POST['section']) || 
			!isset($_POST['cardnumber']) || !isset($_POST['card']) ||
			$_POST['name'] == "" || $_POST['section'] == "" || $_POST['cardnumber'] == "" ||
			$_POST['card'] == "" ) {
				echo
				"<h1>Sorry<h1>
				<p>
					You didnt fill out the form completely.
					<a href=\"https://codd.cs.gsu.edu/~wzhu5/wp/cw/5/buyagrade.html\"> Try again.</a>
				</p>" ;
			}else{
				$new = $_POST['name']. ";" . $_POST['section'].";". $_POST['cardnumber'] .";". $_POST['card'];
				array_push($suckers, $new);
				$file = fopen("suckers.html", "w");
				foreach($suckers as $person) {
					fwrite($file, $person."\n");
				}
				fclose($file);
				echo 
				   "<h1>Thanks, sucker!</h1>

					<p>Your information has been recorded.</p>

					<dl>
						<dt>Name</dt>
						<dd>{$_POST['name']}</dd>

						<dt>Section</dt>
						<dd>{$_POST['section']}</dd>

						<dt>Credit Card</dt>
						<dd>{$_POST['cardnumber']} ({$_POST['card']})</dd>
					</dl>
					<p> Here are all the suckers who have submitted: <p>";
				$page = file_get_contents("suckers.html");
				echo "<pre>";
				echo $page;
				echo "<pre>";
			}
		?>




		<!-- <h1>Thanks, sucker!</h1>

		<p>Your information has been recorded.</p>

		<dl>
			<dt>Name</dt>
			<dd>???</dd>

			<dt>Section</dt>
			<dd>???</dd>

			<dt>Credit Card</dt>
			<dd>???</dd>
		</dl> -->
	</body>
</html> 